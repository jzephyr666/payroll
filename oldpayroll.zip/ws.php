<?php

# Use the link format below: add a month and a year
# http://localhost/payroll/ws.php?month=?&year=?

require_once 'payroll.php';

$qs =  $_SERVER['QUERY_STRING'];

$wsMonth = isset( $_GET['month'] ) ? intval( $_GET['month'] ) : '' ;
$wsYear = isset( $_GET['year'] ) ? intval( $_GET['year'] ) : '' ;

if( $wsMonth && $wsYear ) {

	$wsPayroll = new payroll();
	$wsPayroll->setters($wsMonth, $wsYear);
	$wsPayrollDate = $wsPayroll->getSubmissionDate();
	
	$returnJsonDate = array( "$wsPayrollDate" ) ;
	
	header('Content-type: application/json') ;
	echo json_encode($returnJsonDate);
	
	dbconn( $qs, $wsMonth, $wsYear );
	
} else {
	echo "No Data.";
}

function dbconn( $qs, $m, $y ) {
	
	$mysqli = new mysqli("localhost", "pyuser", "pypass", "py");
	
	if ($mysqli->connect_errno) {
	    printf("Connect failed: %s\n", $mysqli->connect_error);
	    exit();
	}
	
	mysqli_query($mysqli,"INSERT INTO `log`(`querystring`, `month`, `year`) VALUES ($qs,$m ,$y )");
	
	mysqli_close($mysqli);
}

?>